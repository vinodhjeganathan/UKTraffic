﻿namespace DataLayer
{
    /// <summary>
    /// Repository base class
    /// </summary>
    public abstract class RepositoryBase
    {
        protected readonly TrafficRouteDatabaseEntities _context;

        /// <summary>
        /// Constructor for <see cref="RepositoryBase"/>
        /// </summary>
        /// <param name="context">The database context</param>
        public RepositoryBase(TrafficRouteDatabaseEntities context)
        {
            //Created repository base as context will be used in all classes and not to repeat the context declaration as per DRY principle
            _context = context;
        }
    }
}
