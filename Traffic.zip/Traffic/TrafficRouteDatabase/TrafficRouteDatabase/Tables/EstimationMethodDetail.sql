﻿CREATE TABLE [dbo].[EstimationMethodDetail]
(
	[Id] INT NOT NULL,
	[EstimationMethodDetail] NVARCHAR(50) NOT NULL,
	CONSTRAINT PK_EstimationMethodDetail PRIMARY KEY ([Id])
);