﻿CREATE TABLE [dbo].[RoadCategory]
(
	[Id] INT NOT NULL,
	[RoadCategory] NVARCHAR(2) NOT NULL,
	CONSTRAINT PK_RoadCategory PRIMARY KEY ([Id])
);