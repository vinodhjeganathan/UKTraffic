﻿MERGE INTO 
	[dbo].[EstimationMethodDetail] AS Target
USING 
(
	VALUES
	(1,'Automatic counter'),
	(2,'Dependent on a neighbouring counted link'),
	(3,'Estimated from nearby links'),
	(4,'Estimated using previous year''s AADF on this link'),
	(5,'Manual count')
) AS Source ([Id], [EstimationMethodDetail])
ON (Target.[Id] = Source.[Id])
WHEN 
	MATCHED AND (Target.[EstimationMethodDetail] <> Source.[EstimationMethodDetail]) THEN
		UPDATE SET [EstimationMethodDetail] = Source.[EstimationMethodDetail]
WHEN
	NOT MATCHED BY TARGET THEN
		INSERT([Id], [EstimationMethodDetail])
			VALUES(Source.[Id], Source.[EstimationMethodDetail])
WHEN 
	NOT MATCHED BY SOURCE THEN
		DELETE;