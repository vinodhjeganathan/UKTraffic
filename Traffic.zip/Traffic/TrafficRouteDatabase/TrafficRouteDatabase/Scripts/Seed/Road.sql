﻿MERGE INTO 
	[dbo].[Road] AS Target
USING 
(
	VALUES
	(1,'M5'),
	(2,'A379'),
	(3,'A38'),
	(4,'A39'),
	(5,'A303'),
	(6,'A358'),
	(7,'A376'),
	(8,'A380'),
	(9,'A381'),
	(10,'A382'),
	(11,'A383'),
	(12,'A385'),
	(13,'A386'),
	(14,'A388'),
	(15,'A396'),
	(16,'A3052'),
	(17,'A3072'),
	(18,'A361'),
	(19,'A3079'),
	(20,'A35'),
	(21,'A30'),
	(22,'A377'),
	(23,'A3122'),
	(24,'A384'),
	(25,'A3121'),
	(26,'A3123'),
	(27,'A375'),
	(28,'A399'),
	(29,'A373'),
	(30,'A3126'),
	(31,'A3124'),
	(32,'A3125'),
	(33,'A3015'),
	(34,'A390')
) AS Source ([Id], [Road])
ON (Target.[Id] = Source.[Id])
WHEN 
	MATCHED AND (Target.[Road] <> Source.[Road]) THEN
		UPDATE SET [Road] = Source.[Road]
WHEN
	NOT MATCHED BY TARGET THEN
		INSERT([Id], [Road])
			VALUES(Source.[Id], Source.[Road])
WHEN 
	NOT MATCHED BY SOURCE THEN
		DELETE;