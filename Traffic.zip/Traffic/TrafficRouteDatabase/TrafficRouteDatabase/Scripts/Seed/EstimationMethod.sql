﻿MERGE INTO 
	[dbo].[EstimationMethod] AS Target
USING 
(
	VALUES
	(1,'Counted'),
	(2,'Estimated')
) AS Source ([Id], [EstimationMethod])
ON (Target.[Id] = Source.[Id])
WHEN 
	MATCHED AND (Target.[EstimationMethod] <> Source.[EstimationMethod]) THEN
		UPDATE SET [EstimationMethod] = Source.[EstimationMethod]
WHEN
	NOT MATCHED BY TARGET THEN
		INSERT([Id], [EstimationMethod])
			VALUES(Source.[Id], Source.[EstimationMethod])
WHEN 
	NOT MATCHED BY SOURCE THEN
		DELETE;