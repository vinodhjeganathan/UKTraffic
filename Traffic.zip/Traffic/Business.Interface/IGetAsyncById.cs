﻿using System.Threading.Tasks;

namespace Business.Interface
{
    /// <summary>
    /// Interface for Get async by id
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IGetAsyncById<T>
    {
        /// <summary>
        /// Get by id method to retrieve data by id
        /// </summary>
        /// <param name="id">The id</param>
        /// <returns>The object</returns>
        Task<T> GetByIdAsync(int id);
    }
}
