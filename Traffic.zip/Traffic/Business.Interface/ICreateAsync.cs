﻿using System.Threading.Tasks;

namespace Business.Interface
{
    /// <summary>
    /// Interface for creating the record
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface ICreateAsync<T>
    {
        /// <summary>
        /// Create method for recording the new data
        /// </summary>
        /// <param name="dataTransferObject">The data transfer object</param>
        /// <returns>The key of the created object</returns>
        Task<T> CreateAsync(T dataTransferObject);
    }
}