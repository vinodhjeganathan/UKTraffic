﻿namespace Common.Enum
{
    /// <summary>
    /// Enum class for region
    /// </summary>
    public enum Region
    {
        SouthWest = 1
    }
}
